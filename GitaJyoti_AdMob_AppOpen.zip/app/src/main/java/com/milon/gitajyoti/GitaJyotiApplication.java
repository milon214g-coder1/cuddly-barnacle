package com.milon.gitajyoti;

import android.app.Application;

import com.google.android.gms.ads.MobileAds;

public class GitaJyotiApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // AdMob SDK একবারই ইনিশিয়ালাইজ করা হয়, পুরো অ্যাপ চলাকালীন।
        MobileAds.initialize(this, initializationStatus -> { });
        // App Open ad ম্যানেজার — ইউজার অ্যাপে ফিরে এলে অটো লোড/শো করবে।
        new AppOpenAdManager(this);
    }
}
