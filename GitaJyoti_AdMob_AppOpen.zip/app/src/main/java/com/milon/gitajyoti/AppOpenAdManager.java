package com.milon.gitajyoti;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

/**
 * App Open ad — ইউজার যখন অ্যাপে ফিরে আসে (splash/cold-start বা অন্য অ্যাপ থেকে
 * সুইচ করে ফিরে আসা) তখন এই বিজ্ঞাপনটা দেখানো হয়। MainActivity নিজে থেকে ওপেন
 * হওয়ার সাথে সাথে দেখালে ইউজার এক্সপেরিয়েন্স খারাপ হতে পারে, তাই এটা
 * ProcessLifecycleOwner ব্যবহার করে পুরো অ্যাপের "foreground-এ আসা" ইভেন্ট ধরে।
 */
public class AppOpenAdManager implements Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {

    private static final String TAG = "AppOpenAdManager";

    // TEST — publish আগে বদলে দাও: ca-app-pub-6847744858575721/3572008521
    private static final String APP_OPEN_AD_UNIT_ID = "ca-app-pub-3940256099942544/9257395921"; // TEST ID

    // দুইটা লোডের মধ্যে ন্যূনতম গ্যাপ (মিলিসেকেন্ডে) — খুব ঘনঘন অ্যাড না দেখাতে
    private static final long MIN_INTERVAL_MS = 4 * 60 * 60 * 1000; // ৪ ঘণ্টা

    private final Application application;
    private AppOpenAd appOpenAd;
    private boolean isLoadingAd = false;
    private boolean isShowingAd = false;
    private long loadTime = 0;
    private Activity currentActivity;

    public AppOpenAdManager(Application application) {
        this.application = application;
        this.application.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }

    private boolean isAdAvailable() {
        return appOpenAd != null && (System.currentTimeMillis() - loadTime) < MIN_INTERVAL_MS;
    }

    private void loadAd() {
        if (isLoadingAd || isAdAvailable()) return;
        isLoadingAd = true;
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(application, APP_OPEN_AD_UNIT_ID, request,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        appOpenAd = ad;
                        isLoadingAd = false;
                        loadTime = System.currentTimeMillis();
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        isLoadingAd = false;
                        Log.d(TAG, "App open ad failed to load: " + loadAdError.getMessage());
                    }
                });
    }

    private void showAdIfAvailable() {
        if (isShowingAd || currentActivity == null) return;

        if (!isAdAvailable()) {
            loadAd();
            return;
        }

        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                appOpenAd = null;
                isShowingAd = false;
                loadAd(); // পরের বারের জন্য নতুন করে লোড করে রাখা হয়
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                appOpenAd = null;
                isShowingAd = false;
                loadAd();
            }

            @Override
            public void onAdShowedFullScreenContent() {
                isShowingAd = true;
            }
        });
        appOpenAd.show(currentActivity);
    }

    // ---- Application.ActivityLifecycleCallbacks: বর্তমান activity ট্র্যাক করার জন্য ----
    @Override
    public void onActivityCreated(@NonNull Activity activity, Bundle savedInstanceState) { }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) { }

    @Override
    public void onActivityStopped(@NonNull Activity activity) { }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) { }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) { }

    // ---- ProcessLifecycleOwner: পুরো অ্যাপ foreground-এ এলে কল হয় ----
    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        // সামান্য দেরি দিয়ে দেখানো হয় যাতে activity পুরোপুরি রেজিউম হওয়ার সুযোগ পায়
        new Handler(Looper.getMainLooper()).postDelayed(this::showAdIfAvailable, 300);
    }
}
