package com.milon.gitajyoti;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;

    /* =========================================================
       AdMob — এখন Google-এর অফিসিয়াল টেস্ট Ad unit ID ব্যবহার করা
       হচ্ছে, যাতে টেস্টিং নিরাপদে করা যায় (নিজের ডিভাইসে রিয়েল ID
       দিয়ে বারবার অ্যাড দেখলে/ক্লিক করলে AdMob পলিসি ভঙ্গ হয়ে
       অ্যাকাউন্ট সাসপেন্ড হতে পারে)। অ্যাপ পাবলিশ করার ঠিক আগে
       নিচের TEST কনস্ট্যান্ট দুটো কমেন্ট করে REAL গুলো চালু করে দিলেই
       হবে — বাকি কোড অপরিবর্তিত থাকবে।

       GitaJyoti-এর আসল (real) ID গুলো রেফারেন্সের জন্য:
         App ID       : ca-app-pub-6847744858575721~2233087680
         Banner       : ca-app-pub-6847744858575721/7842978336
         Rewarded     : ca-app-pub-6847744858575721/3072620549
         App Open     : ca-app-pub-6847744858575721/3572008521
         Interstitial : ca-app-pub-6847744858575721/5050962332
       (App ID-টা AndroidManifest.xml-এও একইভাবে বদলাতে হবে)
       ========================================================= */
    private static final String BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"; // TEST — publish আগে বদলে দাও: ca-app-pub-6847744858575721/7842978336
    private static final String REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"; // TEST — publish আগে বদলে দাও: ca-app-pub-6847744858575721/3072620549
    private static final String INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"; // TEST — publish আগে বদলে দাও: ca-app-pub-6847744858575721/5050962332

    private FrameLayout bannerAdContainer;
    private AdView bannerAdView;
    private RewardedAd rewardedAd;
    private InterstitialAd interstitialAd;

    // ভিডিও ফিডের ভেতরে প্রতি ৩টা ভিডিওর পর বসানো Banner ad-গুলোর জন্য।
    // JS থেকে পাওয়া প্রতিটা "স্লট"-এর অবস্থান অনুযায়ী আসল AdView-কে
    // WebView-এর উপর ঠিক জায়গায় বসানো হয়, স্লট নাম্বার দিয়ে ট্র্যাক করে
    // (একবার লোড হওয়া ad আবার রিলোড না করে শুধু পজিশন/visibility বদলানো হয়)।
    private FrameLayout feedAdOverlay;
    private final java.util.Map<String, AdView> feedAdViews = new java.util.HashMap<>();

    private ValueCallback<Uri[]> fileUploadCallback;
    private String cameraCaptureUri;
    private static final int FILE_CHOOSER_REQUEST = 5173;
    private static final int PERMS_REQUEST = 9021;

    // Popup WebView used for Firebase signInWithPopup (Google login)
    private Dialog popupDialog;

    private WebViewAssetLoader assetLoader;

    // ইউটিউব ভিডিও ফুলস্ক্রিনে চালানোর জন্য দরকার (HTML5 video fullscreen API)।
    // এগুলো ছাড়া WebView-এর ভেতরে embed করা ইউটিউব ভিডিও প্লে না হয়ে
    // কালো স্ক্রিন দেখাতে পারে বা ফুলস্ক্রিন বাটনে কাজ করে না।
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private int originalOrientation;
    private ViewGroup fullscreenContainer;
    private static final android.widget.FrameLayout.LayoutParams FULLSCREEN_LAYOUT_PARAMS =
            new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        bannerAdContainer = findViewById(R.id.bannerAdContainer);
        feedAdOverlay = findViewById(R.id.feedAdOverlay);

        setupBannerAd();
        loadRewardedAd();
        loadInterstitialAd();

        requestRuntimePermissions();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setGeolocationEnabled(true);
        // Helps Google Sign-In accept the WebView as a normal mobile Chrome browser.
        // Firebase/Google detects embedded WebViews via the "; wv)" marker in the
        // default user agent and blocks signInWithPopup/signInWithRedirect with
        // "auth/operation-not-supported-in-this-environment" when it's present.
        // Removing that marker lets Google Sign-In popups work correctly.
        String ua = settings.getUserAgentString();
        ua = ua.replace("; wv)", ")");
        settings.setUserAgentString(ua + " Chrome/124.0.0.0 Mobile Safari/537.36");

        // Serves files from app/src/main/assets/ under a proper https-like origin
        // (https://appassets.androidplatform.net/assets/...) instead of file://.
        // Firebase Auth (including signInWithPopup) and localStorage need a real
        // http(s) origin to work reliably — file:// often breaks them silently.
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        // JS থেকে সরাসরি ইউটিউব/ফেসবুক/টিকটক ইত্যাদি এক্সটার্নাল লিংক ওপেন করার জন্য ব্রিজ।
        // window.open() ব্যবহার করলে সেটা নতুন WebView পপআপে (onCreateWindow) খুলে যায় —
        // যেটা Google সাইন-ইনের জন্য দরকার হলেও ইউটিউব/ফেসবুক/টিকটকের ক্ষেত্রে সঠিকভাবে
        // কাজ করে না। এই ব্রিজটি সরাসরি Intent.ACTION_VIEW চালিয়ে ফোনে ইনস্টল করা
        // ইউটিউব/ফেসবুক/টিকটক অ্যাপে (থাকলে) বা ব্রাউজারে সরাসরি নিয়ে যায়।
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void openExternalLink(String url) {
                runOnUiThread(() -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) { }
                });
            }
        }, "AndroidBridge");

        // অ্যাপের ভেতরের JS থেকে window.AndroidAd.showRewardedAd() কল করলে এখানে
        // আসল AdMob রিওয়ার্ডেড অ্যাড দেখানো হয় (যেমন: কয়েন সেন্টারের "বিজ্ঞাপন
        // দেখে কয়েন আয়" প্ল্যান)। ইউজার শেষ পর্যন্ত অ্যাডটা দেখলে window.grantAdReward()
        // কল করে JS-কে জানিয়ে দেওয়া হয়, আর ad লোড না থাকলে/দেখানো ব্যর্থ হলে
        // window.gzRewardedAdUnavailable() কল করে জানানো হয়।
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void showRewardedAd() {
                runOnUiThread(MainActivity.this::showRewardedAdIfReady);
            }

            // ইন্টারস্টিশিয়াল অ্যাড দেখানোর জন্য JS থেকে window.AndroidAd.showInterstitialAd()
            // কল করা যায়। অ্যাডটা বন্ধ হলে (বা দেখানো না গেলে)
            // window.gzInterstitialDismissed() কল করে JS-কে জানানো হয়।
            @android.webkit.JavascriptInterface
            public void showInterstitialAd() {
                runOnUiThread(MainActivity.this::showInterstitialAdIfReady);
            }

            // ভিডিও ফিডে স্ক্রল করার সময় JS থেকে বারবার (স্ক্রল হলেই) কল হয়,
            // এখন কোন কোন ad-slot স্ক্রিনে দেখা যাচ্ছে ও কোথায় আছে তা জানিয়ে।
            // JSON ফরম্যাট: [{slot, top, left, width, height, visible}, ...]
            @android.webkit.JavascriptInterface
            public void syncFeedAdSlots(String slotsJson) {
                runOnUiThread(() -> updateFeedAdSlots(slotsJson));
            }
        }, "AndroidAd");

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progressBar.setVisibility(android.view.View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(android.view.View.GONE);
                swipeRefresh.setRefreshing(false);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("https://appassets.androidplatform.net/")) {
                    // Internal app navigation — let the asset loader handle it.
                    return false;
                }
                if (url.startsWith("mailto:") || url.startsWith("tel:") || url.startsWith("intent:")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) { }
                    return true;
                }
                // Allow external https/http links (e.g. Google OAuth) to load
                // normally in this same WebView/popup so sign-in flows complete.
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            // ইউটিউব ভিডিওর ফুলস্ক্রিন বাটনে চাপলে এটি কল হয় — পুরো স্ক্রিন জুড়ে
            // ভিডিওটা দেখানো হয়, ছাড়া এই অংশ বাদ দিলে ফুলস্ক্রিনে গেলে ভিডিও
            // কালো হয়ে যায় বা আটকে থাকে।
            @Override
            public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                originalOrientation = getRequestedOrientation();

                fullscreenContainer = (ViewGroup) getWindow().getDecorView();
                fullscreenContainer.addView(customView, FULLSCREEN_LAYOUT_PARAMS);

                getWindow().getDecorView().setSystemUiVisibility(
                        android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

                webView.setVisibility(View.GONE);
                setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;

                webView.setVisibility(View.VISIBLE);
                fullscreenContainer.removeView(customView);
                customView = null;

                getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_VISIBLE);
                setRequestedOrientation(originalOrientation);

                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                    customViewCallback = null;
                }
            }

            // Handles <input type="file"> for video/image uploads (with camera capture option).
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                              FileChooserParams params) {
                fileUploadCallback = callback;

                Intent contentIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = params.getAcceptTypes();
                String mimeType = (types != null && types.length > 0 && types[0].length() > 0)
                        ? types[0] : "*/*";
                contentIntent.setType(mimeType);

                Intent chooser = Intent.createChooser(contentIntent, "ফাইল নির্বাচন করুন");

                // Add a camera-capture option for image inputs.
                if (mimeType.startsWith("image/")) {
                    try {
                        File photoFile = File.createTempFile(
                                "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()),
                                ".jpg", getExternalCacheDir());
                        cameraCaptureUri = photoFile.getAbsolutePath();
                        Uri photoUri = FileProvider.getUriForFile(MainActivity.this,
                                getApplicationContext().getPackageName() + ".fileprovider", photoFile);
                        Intent camIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                        camIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, photoUri);
                        camIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camIntent});
                    } catch (Exception ignored) { }
                }

                try {
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    fileUploadCallback = null;
                    return false;
                }
                return true;
            }

            // Supports Firebase's signInWithPopup(GoogleAuthProvider) — opens a child WebView.
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                           android.os.Message resultMsg) {
                WebView popupWebView = new WebView(MainActivity.this);
                popupWebView.getSettings().setJavaScriptEnabled(true);
                popupWebView.getSettings().setDomStorageEnabled(true);
                popupWebView.getSettings().setUserAgentString(view.getSettings().getUserAgentString());
                popupWebView.getSettings().setSupportMultipleWindows(true);
                popupWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);

                popupDialog = new Dialog(MainActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                popupDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                popupDialog.setContentView(popupWebView);
                popupDialog.setOnDismissListener(d -> popupDialog = null);

                popupWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest request) {
                        return false;
                    }
                });
                popupWebView.setWebChromeClient(new WebChromeClient() {
                    @Override
                    public void onCloseWindow(WebView window) {
                        if (popupDialog != null) {
                            popupDialog.dismiss();
                        }
                    }
                });

                android.webkit.WebView.WebViewTransport transport =
                        (android.webkit.WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popupWebView);
                resultMsg.sendToTarget();

                popupDialog.show();
                return true;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) { }
        });

        // আগে এখানে সরাসরি webView.reload() করা হতো — এতে উপর থেকে টেনে রিফ্রেশ
        // করলে পুরো WebView-টা নতুন করে লোড হয়ে যেত (স্প্ল্যাশ স্ক্রিন থেকে শুরু হয়ে
        // সরাসরি হোম পেজে চলে আসত), ইউজার যেই পেজে ছিল (যেমন ভিডিও পেজ) সেখান
        // থেকে হারিয়ে যেত। এখন প্রথমে JS-কে (window.appHandleRefresh) জিজ্ঞাসা করা
        // হয় — সে বর্তমান পেজের ডেটা রি-রেন্ডার করে দেয়, পেজ পরিবর্তন হয় না।
        // শুধু JS ব্যর্থ হলে (true রিটার্ন না করলে) পুরনো নিয়মে পুরো পেজ রিলোড হয়।
        swipeRefresh.setOnRefreshListener(() -> webView.evaluateJavascript(
                "(function(){try{return window.appHandleRefresh ? window.appHandleRefresh() : false;}catch(e){return false;}})()",
                value -> {
                    boolean handledInApp = "true".equals(value);
                    swipeRefresh.setRefreshing(false);
                    if (!handledInApp) {
                        webView.reload();
                    }
                }));
        swipeRefresh.setColorSchemeResources(android.R.color.holo_orange_dark);

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        // If the line above ever fails on an older device, use the local asset path instead:
        // webView.loadUrl("file:///android_asset/index.html");
    }

    /* ---- ব্যানার অ্যাড: গেম/অ্যাপের নিচে সবসময় দেখানো হয় ---- */
    private void setupBannerAd() {
        bannerAdView = new AdView(this);
        bannerAdView.setAdUnitId(BANNER_AD_UNIT_ID);
        bannerAdView.setAdSize(AdSize.BANNER);
        bannerAdContainer.addView(bannerAdView);
        bannerAdView.loadAd(new AdRequest.Builder().build());
    }

    /* ---- ভিডিও ফিডের ভেতরে ইন-ফিড Banner ad (প্রতি ৩টা ভিডিওর পর) ----
       JS প্রতিটা ad-slot placeholder-এর স্ক্রিন-পজিশন পাঠায়; সেই অনুযায়ী
       আসল AdView-কে WebView-এর উপর ঠিক জায়গায় বসানো/সরানো হয়। MediumRectangle
       (৩০০x২৫০dp) সাইজ ব্যবহার করা হয়েছে যাতে দেখতে কনটেন্ট কার্ডের মতো লাগে। */
    private void updateFeedAdSlots(String slotsJson) {
        try {
            float density = getResources().getDisplayMetrics().density;
            org.json.JSONArray arr = new org.json.JSONArray(slotsJson);
            java.util.Set<String> stillVisible = new java.util.HashSet<>();

            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject obj = arr.getJSONObject(i);
                boolean visible = obj.optBoolean("visible", false);
                if (!visible) continue;
                String slotId = obj.getString("slot");
                stillVisible.add(slotId);

                AdView adView = feedAdViews.get(slotId);
                if (adView == null) {
                    adView = new AdView(this);
                    adView.setAdUnitId(BANNER_AD_UNIT_ID);
                    adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
                    feedAdOverlay.addView(adView,
                            new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                                    FrameLayout.LayoutParams.WRAP_CONTENT));
                    feedAdViews.put(slotId, adView);
                    adView.loadAd(new AdRequest.Builder().build());
                }

                double top = obj.optDouble("top", 0);
                double left = obj.optDouble("left", 0);
                double slotWidth = obj.optDouble("width", 300);
                // MediumRectangle (৩০০dp চওড়া) স্লটের ভেতরে অনুভূমিকভাবে মাঝ বরাবর বসানো হয়
                double centeredLeft = left + (slotWidth - 300) / 2.0;

                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) adView.getLayoutParams();
                lp.leftMargin = Math.round((float) (centeredLeft * density));
                lp.topMargin = Math.round((float) (top * density));
                adView.setLayoutParams(lp);
                adView.setVisibility(View.VISIBLE);
            }

            // যেসব স্লট আর স্ক্রিনে নেই, সেগুলোর AdView শুধু লুকিয়ে ফেলা হয়
            // (রিসাইকেল/রিলোড করা হয় না, যাতে আবার স্ক্রল করে ফিরলে সাথে সাথেই দেখা যায়)
            for (java.util.Map.Entry<String, AdView> entry : feedAdViews.entrySet()) {
                if (!stillVisible.contains(entry.getKey())) {
                    entry.getValue().setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {
            android.util.Log.d("FeedAdSlots", "sync error: " + e.getMessage());
        }
    }

    /* ---- রিওয়ার্ডেড অ্যাড: কয়েন সেন্টারের "বিজ্ঞাপন দেখে কয়েন আয়" প্ল্যানের জন্য ---- */
    private void loadRewardedAd() {
        RewardedAd.load(this, REWARDED_AD_UNIT_ID, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                        rewardedAd = null;
                    }
                });
    }

    private void showRewardedAdIfReady() {
        if (rewardedAd == null) {
            // এখনো লোড হয়নি — পরের বার রেডি থাকার জন্য আবার লোড করার চেষ্টা করা হয়,
            // আর এই মুহূর্তে JS-কে জানিয়ে দেওয়া হয় যাতে ওখানে বাটন/প্ল্যান রিসেট হয়।
            loadRewardedAd();
            notifyRewardedAdUnavailableToJs();
            return;
        }
        rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                rewardedAd = null;
                loadRewardedAd(); // পরের বারের জন্য নতুন করে লোড করে রাখা হয়
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                rewardedAd = null;
                loadRewardedAd();
                notifyRewardedAdUnavailableToJs();
            }
        });
        rewardedAd.show(MainActivity.this, rewardItem -> webView.post(() ->
                webView.evaluateJavascript(
                        "window.grantAdReward && window.grantAdReward();", null)));
    }

    private void notifyRewardedAdUnavailableToJs() {
        webView.post(() -> webView.evaluateJavascript(
                "window.gzRewardedAdUnavailable && window.gzRewardedAdUnavailable();", null));
    }

    /* ---- ইন্টারস্টিশিয়াল অ্যাড: প্রতিটা লেভেল জেতার পর দেখানো হয় ---- */
    private void loadInterstitialAd() {
        InterstitialAd.load(this, INTERSTITIAL_AD_UNIT_ID, new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd ad) {
                        interstitialAd = ad;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                        interstitialAd = null;
                    }
                });
    }

    private void notifyInterstitialDismissedToJs() {
        webView.post(() -> webView.evaluateJavascript(
                "window.gzInterstitialDismissed && window.gzInterstitialDismissed();", null));
    }

    private void showInterstitialAdIfReady() {
        if (interstitialAd == null) {
            // অ্যাড রেডি নেই — গেম আটকে না থেকে সাথে সাথে পরের লেভেলে চলে যাক,
            // পরের বার দেখানোর জন্য এখনই আবার লোড করে রাখা হয়।
            loadInterstitialAd();
            notifyInterstitialDismissedToJs();
            return;
        }
        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                interstitialAd = null;
                loadInterstitialAd(); // পরের লেভেল জেতার জন্য নতুন করে লোড করে রাখা হয়
                notifyInterstitialDismissedToJs();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                interstitialAd = null;
                loadInterstitialAd();
                notifyInterstitialDismissedToJs();
            }
        });
        interstitialAd.show(MainActivity.this);
    }

    private void requestRuntimePermissions() {
        String[] perms;
        if (Build.VERSION.SDK_INT >= 33) {
            perms = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
            };
        } else {
            perms = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
        }
        boolean needed = false;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needed = true;
                break;
            }
        }
        if (needed) {
            ActivityCompat.requestPermissions(this, perms, PERMS_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (fileUploadCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data == null || data.getData() == null) {
                    // Came from the camera-capture intent.
                    if (cameraCaptureUri != null) {
                        results = new Uri[]{Uri.fromFile(new File(cameraCaptureUri))};
                    }
                } else {
                    results = new Uri[]{data.getData()};
                }
            }
            fileUploadCallback.onReceiveValue(results);
            fileUploadCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bannerAdView != null) bannerAdView.resume();
    }

    @Override
    protected void onPause() {
        if (bannerAdView != null) bannerAdView.pause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (bannerAdView != null) bannerAdView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            webView.getWebChromeClient().onHideCustomView();
            return;
        }
        if (popupDialog != null) {
            popupDialog.dismiss();
            return;
        }
        // অ্যাপটি একটি সিঙ্গেল-পেজ JS অ্যাপ (URL/history পরিবর্তন হয় না বলে
        // webView.canGoBack() প্রায় সবসময় false থাকে), তাই সরাসরি WebView history
        // দিয়ে ব্যাক হ্যান্ডেল করলে প্রথম ব্যাক চাপেই অ্যাপ বন্ধ হয়ে যেত।
        // এখন প্রথমে JS-কে জিজ্ঞাসা করা হয় সে নিজে ভেতরের পেজ-হিস্ট্রি/মোডাল
        // দিয়ে ব্যাক হ্যান্ডেল করতে পারবে কিনা।
        webView.evaluateJavascript(
                "(function(){try{return window.appHandleBackPress ? window.appHandleBackPress() : false;}catch(e){return false;}})()",
                value -> {
                    boolean handledInApp = "true".equals(value);
                    if (!handledInApp) {
                        if (webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            finish();
                        }
                    }
                });
    }
}
